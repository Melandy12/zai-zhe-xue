---
name: zjooc-homework-runner
description: 在浙江省高等学校在线开放课程共享平台（zjooc.cn，又称「在浙学」）批量完成并提交课程作业。当用户要求「把某某课的作业做了/写了/提交了」「爬取作业题目帮填答案」「批量刷课程作业」「核对该课程作业提交情况和得分」，或给出 www.zjooc.cn/ucenter/student/course/... 的课程作业链接时使用。覆盖作业清单抓取、题型提取、单选/多选/填空作答、逐份提交、提交后核验与得分汇总。不用于在线测验（测验/考试模块）与讨论区发帖。
---

# 在浙学（zjooc）课程作业批量作答与提交

用 Browser Use（`computer_use_tool` + `plane="bu"` + `import aha_browser_use as bu`）操作真实页面。不要自己构造站点 ajax 请求：该网关的 `time` 参数是签名令牌，自造请求一律返回 `404 | Page Not Found`。

## 前置条件

1. `bu.navigate` 打开目标课程页，读 `bu.page_info()` 和 `bu.get_page_text()`：
   - 落在首页且有「请登录」→ 立刻 `interaction_request_action`（`type="browserControl"`）交接登录，不要尝试账号密码。
   - 右上角出现学生姓名 → 已登录，继续。
2. URL 形态：
   - 作业列表：`/ucenter/student/course/study/<courseId>/homework`
   - 答题页：`.../homework/do/<paperId>?from=...&processStatus=0&classId=<classId>`
   - 批改结果：`.../homework/result/<paperId>/processStatus/1`

## 硬性约束（违反必然出错，逐条确认）

1. **只能从列表点「去作业」进入答题页**。直接 navigate 到 `/homework/do/<paperId>`（缺 `classId`）会得到空壳：标题空、无题目、无提交按钮。`paperId` 只能从点击后的 `page_info()['url']` 取。
2. **选项必须原生单点**：每个选项一次 `bu.click(ref)`，之前先 `bu.scroll_into_view(ref)`。报 `No verified activation point for radio/checkbox or its labels` 多是元素在视口外或有浮层，可退化为 JS 按索引单点。**禁止**在一个 JS 里连点多个 checkbox：Vue 来不及刷新，实测只记最后一个选项，而 DOM 的 `input.checked` 仍全为 true —— 看着填好了，实际只提交一项。
3. **快照必须限定题库区域**：`bu.snapshot(within=bu.css("main", match="first"), view="interactive", max_chars=30000)`。默认 `within="viewport"` 会漏掉视口外的题。
4. **填空题抓长题干**：短截断会让多空题无法作答，题干切到 400 字以上；`ntxt>=3` 的条目单独抓全文。
5. **提交是两步**：点「提交」→ 在 `.el-message-box` 里点「确定」。点完没弹窗不代表失败，先读 `.el-message` 的提示文案。

## 标准流程

### 1. 抓作业清单
Element UI 表格 + 分页（默认 20 条/页），标题在每行第一个 `.cell`。进入某行：

```js
var rows = document.querySelectorAll('tbody tr');
rows[i].querySelector('button').click();
```

三个坑：
- `tbody tr` 会返回「主表 + 固定列」两份，操作列 `td` 带 `is-hidden`，其按钮 `innerText` 为空 —— 判断文案必须用 `textContent.indexOf('去作业') >= 0`。
- 翻页：`.el-pager li.number` 的第 0/1 项即第 1/2 页。
- 提交后按钮变「已提交」，所以「标题前缀 + 按钮含『去作业』」的定位天然幂等，重复跑会跳过已交的。

### 2. 提取题目与题型
遍历 `.questiono-item`：含 `input[type=checkbox]` → 多选；含 `input[type=radio]` → 单选；只有 `input.el-input__inner` → 填空，空位数 = 输入框数量。题干取 `.questiono-header h6`，选项取 `label` 的 `textContent`。

### 3. 作答映射
快照中 `radio` / `checkbox` / `textbox` 各自成队列，**按文档顺序消费**：
- 单选：该题 k 个选项、答案字母 X → `radios[ri + (X-A)]`，然后 `ri += k`
- 多选：答案 `ABD` → 取 `checks[ci + 0..k-1]` 中对应字母，然后 `ci += k`
- 填空：按空位顺序 `texts[ti + j]`，然后 `ti += n`

动手前先断言 `(r, c, t)` 三组数量与答案规格完全一致；不一致就中止该份，说明题型提取错了，不要硬填。

### 4. 提交与兜底
- 点「提交」→ 等 2 秒 → 读 `.el-message`。
- 出现 `有题目未提交，请补充`：说明某题没进模型。用 JS 逐项补点，每次之间 `time.sleep(0.6)`，复查 `label.classList.contains('is-checked')` 全为真后再提交。
- 正常出现「确认提交」→ 点「确定」→ 回列表。

### 5. 核验（不可省）
回列表翻遍所有页，统计按钮仍为「去作业」的条目，**必须为 0**，并输出每行得分。只凭「提交返回 ok」不算完成。

## 判分口径（写总结时必须说清）

- 单选、多选自动判分；多选按 **选对选项数 / 选项总数 × 满分** 给部分分，漏选会出现 0.5、0.7 这类分值。
- **填空题由老师人工批阅**，提交后得分列为空；整份全是填空时显示 `0/10` 不等于答错，只是还没批。汇报时必须点明，否则用户会误判。
- 状态列区分「已批阅」（老师已给分）与「已提交」（待批）。
- 结果页只有「我的答案 + 得分」，**不给正确答案**，别指望从批改页反推答案。

## 参考资料

- `references/browser-recipes.md`：可直接粘进 `computer_use_tool` 单元格的完整实现（列表定位、快照解析、按题型填答、提交兜底、核验汇总）及已核验的 DOM 细节。写代码前先读它。

# 在浙学（zjooc）课程作业自动化 Skill 总说明

> 适用平台：浙江省高等学校在线开放课程共享平台（www.zjooc.cn，又称「在浙学」）
> 适用任务：批量完成并提交某门课的作业（作业清单抓取 → 题型提取 → 作答 → 逐份提交 → 核验汇总）
> 不适用：测验 / 考试模块、讨论区发帖
> 本文档合并自 Skill 文件夹内的 `SKILL.md` 与 `references/browser-recipes.md`，两个原文件同目录留存备查。

---

## 一、这份文档解决什么

同一门课的作业常常是「七八十份 × 每份 5 题」的量级，手工点选既慢又容易漏题。把这套流程固定下来后，一次可以跑完几十份，并且**每份都有提交与核验闭环**，不是填完就算。

代价是这套流程有几个反直觉的坑：有些操作「看起来成功了，其实没有」。下面第二节全部是实测踩出来的，复用前请逐条读完——它们决定了整件事能不能做对。

---

## 二、实测踩过的坑（重点，先看这一节）

| # | 坑 | 现象 | 正确做法 |
|---|---|---|---|
| 1 | 直连答题页网址 | `bu.navigate` 到 `/homework/do/<paperId>` 后页面是空壳：标题空、无题目、无提交按钮 | 必须回列表点「去作业」进入，`paperId` 从点击后的 `page_info()['url']` 里取。直连缺 `classId` 参数，页面拿不到题目 |
| 2 | 一个 JS 里批量点 checkbox | 视觉上 4 个选项都打勾了，提交后「我的答案」只有最后一个 | 每次点击一次 `bu.click(ref)`（先 `scroll_into_view`）。元素在视口外或有浮层时退化为 JS 按索引单点，且只点一个 |
| 3 | 用 `input.checked` 判断是否选中 | 显示全选中，模型里其实只有一个 | 只认 `label.classList.contains('is-checked')`，Element UI 的选中态挂在 label 上 |
| 4 | 默认视口快照 | `snapshot()` 只返回视口内控件，一屏放不下的题全部丢失，后面按数量断言会失败 | `bu.snapshot(within=bu.css("main", match="first"), view="interactive", max_chars=30000)` |
| 5 | 用 `innerText` 读按钮文案 | 操作列 `td` 带 `is-hidden`，按钮 `innerText` 为空，找不到「去作业」 | 一律用 `textContent`，判断 `textContent.indexOf('去作业') >= 0` |
| 6 | 表格行重复 | `tbody tr` 返回「主表 + 固定列」两份，同名行出现两次 | 按「标题前缀 + 按钮含『去作业』」定位，天然幂等；同时要意识到同名副本会被去重，统计总数时别漏算 |
| 7 | 提交只点一次 | 页面停在答题页，作业仍是「去作业」状态 | 提交是两步：「提交」→ `.el-message-box` 里点「确定」 |
| 8 | 漏答被静默拦下 | 点提交后不弹窗，也不报错，看着像卡住 | 读 `.el-message` 文案：`有题目未提交，请补充` 说明某题没进模型 → 逐项补点（间隔 0.6s）后重提 |
| 9 | 题干截断 | 多空填空题只看到前半句，无法确定每个空要填什么 | 题干切到 400 字以上；空位数 ≥3 的条目单独抓全文再作答 |
| 10 | 以为能调站点接口批量抓题 | 自己拼 `/ajax?service=...` 请求一律 `404 \| Page Not Found` | `time` 参数是签名令牌，无法自造。路线只能是浏览器操作真实页面 |
| 11 | 误判 0 分 | 「第五章（1）0/10」「第三章（4）0/10」看着像全错 | 填空题**由老师人工批阅**，提交后得分列为空；整份全是填空时自动分就是 0，等老师批完才有分 |
| 12 | 多选部分分 | 明明选对一项，却只有 0.7、0.5 这种分数 | 多选按 **选对选项数 / 选项总数 × 满分** 给分，漏选必然掉分；0.7 常来自 3 选 1 的正确项 |
| 13 | 想从批改页反推答案 | 结果页「题目解析」永远是空的 | 平台不公布正确答案，学不到答案，别浪费时间 |
| 14 | 结果页答案块选错 class | 用 `.common_test_myanswer` 取不到答案，漏填空被误判成已填 | 答案块真实 class 是 `.common_test_answer`；答案形如 `我的答案: B` / `[B,C,D]` / `[, , , ]`，剥前缀和 `[]` 按逗号切分，空串位置即漏填 |
| 15 | 填空静默留空就提交 | 提交接口不拦空框，列表显示「已提交」，结果页却是 `[, , , ]` | 提交前遍历填空输入框做空值断言（spec 显式给空串除外），有空白框直接中止报 `BLANK_FILL`；提交后必须回结果页回读 `.common_test_answer` 复查空答案 |
| 16 | 靠联网搜填空答案 | 填空题是教材原文措辞，通用网页搜不到标准答案；没有题库时硬填，往往填错 | **动手前先到外部题库目录 `E:\Doubao_AI_Output\在浙学\答案文件\` 读取本课程题库（标准答案 PDF、往届答卷、截图）**，用户新给的答案也放这里；按题干匹配题库作答。题库缺题的填空留空并标注「题库无此题」，不要编造；无题库就先做单选/多选，填空等答案放进目录 |

---

## 二·五、审查机制（四道关卡，任一不过即中止，不得带病提交）

> 审查规范已内置在本 skill 的 `SKILL.md`「审查机制」章节（复盘表 + 四道关卡 + 异常分级 + 禁止事项），不另出外部方案文档。本次漏填/错答的根因就是缺审查关卡：填完即提交、提交后不回读、无题库也硬填。

| 关卡 | 时机 | 审查项 | 不过的处置 / 异常码 |
|---|---|---|---|
| Gate-0 题库准入 | 开工前 | 题库来源与覆盖范围已确认；填空答案可追溯到题库；扫描件已渲染读取 | 无题库不填填空；题库缺题留空标注；禁止联网猜答案 |
| Gate-1 解析断言 | 答题前 | 快照全量限定 main；题型判对；控件数 `(r,c,t)` 与 spec 汇总一致 | 不符即中止：`COUNT_MISMATCH`；进不去：`OPEN_FAIL`；无提交钮：`NO_SUBMIT` |
| Gate-2 提交前自检 | 点提交前 | 单选/多选 `is-checked` 复查；填空无未声明空框；答案逐条对回题库 | 空框中止：`BLANK_FILL`；选中态不符：`CHECK_STATE`；未进模型：`INCOMPLETE` |
| Gate-3 提交后回读 | 提交后单份 | 结果页 `.common_test_answer` 逐题回读，空串记 `CHECK`、与题库不符记 `WRONG` | 可编辑态补填重提；只读态记入待老师退回清单，不谎报完成；读不到：`READ_FAIL` |
| Gate-4 整批复盘 | 批量收尾 | 翻页对账，输出漏填 / 错题存疑 / 待批三清单；待批 0 分不等于答错 | 未交条目列明；汇报分清自动分与人工分 |

**核心原则**：审查先于提交；以页面真实状态（`is-checked`、结果页回读）为准，不信接口 ok / 按钮文案；答案可追溯；异常显式分级不静默吞掉。

---

## 三、标准流程

### 0. 前置：题库 + 登录态

**0.1 先确认题库（最重要）**
- 动手作答前，先到外部题库目录 `E:\Doubao_AI_Output\在浙学\答案文件\` 读取本课程题库/标准答案；用户新给的答案也统一放到这个目录。填空题是教材原文措辞，联网搜不到，**严禁凭推测或通用网页答案编造填空**。
- 有题库：按题干匹配题库答案；题库缺题的填空留空，汇报标注「题库无此题」。无题库：先做单选/多选，填空等用户补题库。
- 扫描件 PDF（无文字层，`get_text` 为空）：用 pymupdf 渲染成 PNG 再视觉读取；PDF 节号 `(章-节)` 对应平台标题「第X章（Y）」。

**0.2 登录态**
打开课程页后先看两处：
- 落在首页且有「请登录」→ 说明未登录，走登录交接（`interaction_request_action`，`type="browserControl"`），不要尝试账号密码。
- 右上角出现学生姓名 → 已登录，直接往下走。

### 1. 抓作业清单
列表是 Element UI 表格 + 分页（默认 20 条/页），标题在每行第一个 `.cell`。

- 进入某行：`rows[i].querySelector('button').click()`
- 翻页：`.el-pager li.number` 的第 0、1 项分别是第 1、2 页
- 已提交的行按钮会变成「已提交」，所以同一套定位可以重复跑，会自动跳过已交的

### 2. 提取题目与题型
遍历 `.questiono-item`，靠子控件判型：

| 子控件 | 题型 |
|---|---|
| `input[type=checkbox]` | 多选 |
| `input[type=radio]` | 单选 |
| 仅 `input.el-input__inner` | 填空（空位数 = 输入框个数） |

题干取 `.questiono-header h6`，选项文案取 `label` 的 `textContent`。

**结果页答案块真实 class 是 `.common_test_answer`（不是 `.common_test_myanswer`）**：答案文案 `我的答案: B` / `我的答案: B,C,D` / `我的答案: [, , , ]`，得分在同一块 `得分: x`。解析填空漏填：剥掉 `我的答案:` 前缀和外层 `[]`，按英文逗号切分、去首尾空白，空串即漏填空；`[, , , ]` 全空，`[局部, , , ]` 部分漏填。

### 3. 作答映射
快照里 `radio` / `checkbox` / `textbox` 各自成队列，**按文档顺序消费**：

- 单选：该题 k 个选项、答案字母 X → `radios[ri + (X-A)]`，然后 `ri += k`
- 多选：答案 `ABD` → 取 `checks[ci + 0..k-1]` 中对应字母，然后 `ci += k`
- 填空：按空位顺序 `texts[ti + j]`，然后 `ti += n`

**动手前先断言 (单选控件数, 多选控件数, 填空控件数) 与答案规格完全一致**。不一致就中止该份——那说明题型识别错了，硬填只会写错位置。

### 4. 提交与兜底
1. **提交前空值断言**：遍历每题填空输入框，`value.trim()===''` 且 spec 未显式标记留空的，中止该份报 `BLANK_FILL`；多选/单选复查 `is-checked` 与规格一致。
2. 点「提交」→ 等 2 秒 → 读 `.el-message`
3. 出现 `有题目未提交，请补充` → 逐项补点 + 复查 `is-checked` → 重新提交
4. 出现「确认提交」弹窗 → 点「确定」→ 页面自动回列表
5. **提交后回结果页回读校验**：从列表点行内按钮进 `/result/<paperId>/processStatus/1`，解析 `.common_test_answer` 逐题比对，出现空串答案记 `CHECK`；不能只凭按钮变「已提交」判完成。

### 5. 核验（不可省）
回列表翻遍所有页，统计按钮仍为「去作业」的条目，**必须为 0**，再把每行得分一起输出。只凭「提交返回 ok」不算完成。

---

## 四、完整实现代码

下面代码全部在 `computer_use_tool(plane="bu")` 单元格内运行，开头 `import aha_browser_use as bu`。每个单元格是新进程，helper 要一起带上。

### 0. 常量

```python
LIST = "https://www.zjooc.cn/ucenter/student/course/study/<courseId>/homework"
```

### 1. 解析快照为 ref 队列

```python
import re
def parse_snap(s):
    out = []
    for line in str(s).splitlines():
        m = re.match(r'^\s*(n\d+)\s+(radio|checkbox|textbox|button)\s+"(.*)"', line)
        if m:
            out.append((m.group(1), m.group(2), m.group(3)))
    return out

snap = parse_snap(bu.snapshot(within=bu.css("main", match="first"),
                             view="interactive", max_chars=30000))
radios = [r for r, t, v in snap if t == "radio"]
checks = [r for r, t, v in snap if t == "checkbox"]
texts  = [r for r, t, v in snap if t == "textbox"]
sub    = [r for r, t, v in snap if t == "button" and "提交" in v]
```

### 2. 定位并打开某份作业（幂等）

标题只在 `-副本` 之前有效，比较时去掉所有空白并只做前缀匹配。

```python
import time, json
def norm(s):
    return re.sub(r'\s+', '', s or '')

def open_a(title):
    t = norm(title)
    for page in (1, 2, 3):
        bu.navigate(LIST)
        bu.wait_for_load(timeout=15)
        bu.wait_for_element("tbody tr", visible=True, timeout=15)
        if page > 1:
            bu.js("(()=>{var n=document.querySelectorAll('.el-pager li.number');"
                  "var k=%d; if(n.length>k){n[k].click(); return 1;} return 0;})()" % (page - 1))
            time.sleep(2)
        idx = bu.js("""(()=>{var rows=Array.from(document.querySelectorAll('tbody tr'));
            var tgt=%s;
            for(var i=0;i<rows.length;i++){
              var c=rows[i].querySelector('.cell'), b=rows[i].querySelector('button');
              if(!c||!b) continue;
              if(c.textContent.replace(/\\s+/g,'').trim().indexOf(tgt)===0
                 && b.textContent.indexOf('去作业')>=0) return i;
            } return -1;})()""" % json.dumps(t))
        if int(idx) >= 0:
            bu.js("(()=>{var r=document.querySelectorAll('tbody tr')[%d];"
                  "r.querySelector('button').click(); return 1;})()" % int(idx))
            time.sleep(3)
            bu.wait_for_element(".questiono-item", visible=True, timeout=15)
            return True
    return False
```

### 3. 选项点击（原生优先，JS 兜底）

```python
def click_opt(kind, i, queue):
    sel = "input[type=radio]" if kind == 'r' else "input[type=checkbox]"
    try:
        ref = queue[i]
        bu.scroll_into_view(ref)
        time.sleep(0.15)
        bu.click(ref)
    except Exception:
        bu.js("(()=>{var e=document.querySelectorAll('.questiono-item %s')[%d];"
              "if(!e) return 0; var l=e.closest('label'); (l||e).click(); return 1;})()" % (sel, i))
```

### 4. 一份作业的完整动作

`spec` 是答案规格，每项为 `('s', 选项数, 'B')` / `('m', 选项数, 'ABD')` / `('f', 空位数, ['答案1','答案2'])`，顺序与页面题目顺序一致。

```python
def do_one(title, spec):
    if not open_a(title):
        return title + " OPEN_FAIL"
    snap = parse_snap(bu.snapshot(within=bu.css("main", match="first"),
                                 view="interactive", max_chars=30000))
    radios = [r for r, t, v in snap if t == "radio"]
    checks = [r for r, t, v in snap if t == "checkbox"]
    texts  = [r for r, t, v in snap if t == "textbox"]
    sub    = [r for r, t, v in snap if t == "button" and "提交" in v]

    dom = dict(r=len(radios), c=len(checks), t=len(texts))
    exp = dict(r=sum(k for t, k, v in spec if t == 's'),
               c=sum(k for t, k, v in spec if t == 'm'),
               t=sum(k for t, k, v in spec if t == 'f'))
    if dom != exp:                      # 题型识别错了，别硬填
        return title + " COUNT_MISMATCH dom=%s exp=%s" % (dom, exp)

    ri = ci = ti = 0
    for typ, k, val in spec:
        if typ == 's':
            click_opt('r', ri + ord(val) - 65, radios); ri += k
        elif typ == 'm':
            for L in val:
                click_opt('c', ci + ord(L) - 65, checks)
            ci += k
        else:
            for j, v in enumerate(val):
                bu.type(texts[ti + j], v, submit=False)
            ti += k

    time.sleep(0.6)
    if not sub:
        return title + " NO_SUBMIT"

    try:
        bu.click(sub[0])
    except Exception:
        bu.js("(()=>{var bs=Array.from(document.querySelectorAll('button'));"
              "for(var i=0;i<bs.length;i++){if(bs[i].innerText.trim()==='提交'){bs[i].click(); return 1;}}"
              "return 0;})()")
    time.sleep(2.5)

    msg = bu.js("(()=>{var m=Array.from(document.querySelectorAll('.el-message'))"
                ".map(function(e){return e.innerText.trim();}); return m.join('|');})()")
    if msg and '未提交' in msg:          # 有题漏答，逐项补点后重提
        return title + " INCOMPLETE: " + msg

    r = bu.js("(()=>{var ds=Array.from(document.querySelectorAll('.el-message-box'));"
              "if(!ds.length) return 'nodialog';"
              "var bs=ds[0].querySelectorAll('button');"
              "for(var i=0;i<bs.length;i++){if(bs[i].innerText.trim()==='确定'){bs[i].click(); return 'ok';}}"
              "return 'no_confirm';})()")
    time.sleep(3)
    return title + " -> " + str(r)
```

批量跑时按 4~5 份一组，单次单元格控制在 3 分钟内；每份结束用 `flush=True` 打日志，出错也不至于全丢。

### 5. 漏答兜底（配合第 4 节的 INCOMPLETE）

```python
# 对第 qi 题（0 基）按答案字母逐个点，每次间隔 0.6s
for L in 'ABCD':
    bu.js("""(()=>{var it=document.querySelectorAll('.questiono-item')[%d];
        var e=it.querySelector('input[value="%s"]'); if(!e) return 0;
        var l=e.closest('label'); (l||e).click(); return 1;})()""" % (qi, L))
    time.sleep(0.6)

# 复查：is-checked 才是模型真实状态
bu.js("""(()=>{var it=document.querySelectorAll('.questiono-item')[%d];
    return JSON.stringify(Array.from(it.querySelectorAll('label'))
      .map(function(l){return l.classList.contains('is-checked')?'Y':'N';}));})()""" % qi)
```

### 6. 核验与汇总

```python
def dump_rows():
    return bu.js("""(()=>{var rows=Array.from(document.querySelectorAll('tbody tr'));
      var out=[], seen={};
      rows.forEach(function(r){var c=r.querySelectorAll('.cell'); if(!c.length) return;
        var name=c[0].textContent.replace(/\\s+/g,'').trim().split('-副本')[0];
        var score=c[3]?c[3].textContent.replace(/\\s+/g,' ').trim():'';
        var b=r.querySelector('button'); var bt=b?b.textContent.trim():'';
        if(!name) return; var key=name+'|'+score+'|'+bt; if(seen[key]) return; seen[key]=1;
        out.push(name+' | '+score+' | '+bt);});
      return JSON.stringify(out);})()""")
```

- 同名副本会被去重，**统计总数时要自己加上重复份**
- 判定完成：所有页里「去作业」条目数 = 0
- 得分读第 4 列（`c[3]`），形如 `5.2/10.0`；`--/10.0` 表示未提交

---

## 五、判分口径（写汇报时要说清）

- **单选、多选自动判分**；多选按「选对选项数 / 选项总数 × 满分」给部分分，漏选会出现 0.5、0.7 这类分值。
- **填空题由老师人工批阅**，提交后得分列为空。整份全是填空时显示 `0/10` 不等于答错，只是还没批。汇报时必须点明，否则会被误读成全错。
- 状态列区分「已批阅」（老师已给分）与「已提交」（待批）。
- 结果页只有「我的答案 + 得分」，不公布正确答案。

---

## 六、复用前自检清单

- [ ] Gate-0：题库已确认来源与覆盖范围，填空答案可追溯到题库
- [ ] 浏览器已登录（右上角有学生姓名），不是停在首页
- [ ] Gate-1：快照用了 `within=main`（非默认 viewport），题型判对，控件数量与规格断言通过
- [ ] 选项是逐个原生点击，没有在同一个 JS 里连点；选中态认 `is-checked`
- [ ] Gate-2：提交前空值断言通过、选中态复查通过，答案逐条对回题库
- [ ] 提交后点了弹窗「确定」
- [ ] Gate-3：回结果页 `.common_test_answer` 回读，无空串、答案与题库一致（或已记 CHECK/WRONG）
- [ ] Gate-4：整批对账完成，漏填 / 错题存疑 / 待批三清单齐全
- [ ] 汇报里说明了填空题待人工批阅

---

## 七、文件清单

| 文件 | 说明 |
|---|---|
| `在浙学作业Skill总说明.md` | 本文档：坑总结 + 完整流程 + 全部代码 |
| `SKILL.md` | 装进 Skill 目录的原始说明文件（含 frontmatter，用于触发） |
| `browser-recipes.md` | Skill 的参考资料原文（可在 `computer_use_tool` 里直接粘贴的代码块） |
| `E:\Doubao_AI_Output\在浙学\答案文件\`（外部题库目录，skill 运行时读取） | 本课程题库/往届标准答案归档处；当前含《2_工程与社会答案(1).pdf》（扫描件，每题带「正确答案」）。新答案也放此目录，skill 不内置题库副本 |

Skill 在系统中的安装位置：

```
C:\Users\MECHREVO\AppData\Local\Doubao\User Data\Default\.doubao\agent_mode\workspace\.user_skills\zjooc-homework-runner\
```

---

## 附：这次实际跑的结果（供参考量级）

某门课 29 份作业 × 每份 10 分：

- 全部 29 份提交成功，核验「去作业」条目数 = 0
- 已批阅 3 份：10/10、10/10、6/10
- 自动判分合计约 123.2 / 290，其余分差集中在待人工批阅的填空题
- 纯填空题的几份（如第五章（1）、第三章（1)(2)(4)）自动分为 0，属正常现象

> 提示：**已提交（状态 1）/ 已批阅（状态 2）的作业，学生前端只能进结果页只读，没有撤回/重做入口**；只有老师在后台把作业退回为「撤回重做」态（状态 3），列表才会出现「撤回重做」按钮、可重新编辑。ajax 网关 `time` 是签名令牌，不能自造请求绕过。若要补做已提交的漏填空，需先联系任课老师开放退回。

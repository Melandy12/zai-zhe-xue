# 可复用实现（已实测通过）

以下代码全部在 `computer_use_tool(plane="bu")` 单元格内运行，`import aha_browser_use as bu`。`cell` 每次都是新进程，所以每次都要把 helper 一起带上。

## 0. 题库优先（作答前先做）

- **动手前先到外部题库目录 `E:\Doubao_AI_Output\在浙学\答案文件\` 读取本课程题库/标准答案**（PDF、Word、截图）；用户新给的答案也统一放到这个目录，skill 不内置题库副本。填空题是教材原文措辞，联网搜不到标准答案，**严禁凭推测或通用网页答案编造填空**。
- 有题库：按题干匹配题库答案后填；题库缺题的填空留空，并在汇报中标注「题库无此题」。目录内多份材料时按课程名/作业标题匹配。
- 题库若是**扫描件 PDF（无文字层，`get_text` 返回空）**：用 miniconda Python + pymupdf 渲染成 PNG 再视觉读取，不要直接 `get_text`：

```python
import pymupdf, os, glob
BANK_DIR = r"E:\Doubao_AI_Output\在浙学\答案文件"
# 先列目录，按课程名/标题选对应 PDF
pdfs = glob.glob(os.path.join(BANK_DIR, "*.pdf"))
src = pdfs[0]  # 按标题匹配后替换
out = r"E:\Doubao_AI_Output\_agent-workspace\tmp\ans_pdf"
os.makedirs(out, exist_ok=True)
doc = pymupdf.open(src)
for i, page in enumerate(doc, 1):
    pix = page.get_pixmap(matrix=pymupdf.Matrix(2, 2), alpha=False)
    pix.save(os.path.join(out, f"p{i:02d}.png"))
# 再用 Read 逐张看 PNG，按 PDF 分节号（如 10(3-4)）对应平台作业标题（如 第三章（4））
```

- 匹配口径：PDF 节号 `(章-节)` 对应平台标题「第X章（Y）」；单选/多选取「正确答案: 字母」，填空取「正确答案: [[...]]」数组，按空位顺序填。

## 0.1 常量

```python
LIST = "https://www.zjooc.cn/ucenter/student/course/study/<courseId>/homework"
```

## 1. 解析快照为 ref 队列

```python
import re
def parse_snap(s):
    out = []
    for line in str(s).splitlines():
        m = re.match(r'^\s*(n\d+)\s+(radio|checkbox|textbox|button)\s+"(.*)"', line)
        if m:
            out.append((m.group(1), m.group(2), m.group(3)))
    return out

snap = parse_snap(bu.snapshot(within=bu.css("main", match="first"),
                             view="interactive", max_chars=30000))
radios = [r for r, t, v in snap if t == "radio"]
checks = [r for r, t, v in snap if t == "checkbox"]
texts  = [r for r, t, v in snap if t == "textbox"]
sub    = [r for r, t, v in snap if t == "button" and "提交" in v]
```

## 2. 定位并打开某份作业（幂等）

标题只在 `-副本` 之前有效，比较时去掉所有空白，并只做前缀匹配。

```python
import time, json
def norm(s):
    return re.sub(r'\s+', '', s or '')

def open_a(title):
    t = norm(title)
    for page in (1, 2, 3):
        bu.navigate(LIST)
        bu.wait_for_load(timeout=15)
        bu.wait_for_element("tbody tr", visible=True, timeout=15)
        if page > 1:
            bu.js("(()=>{var n=document.querySelectorAll('.el-pager li.number');"
                  "var k=%d; if(n.length>k){n[k].click(); return 1;} return 0;})()" % (page - 1))
            time.sleep(2)
        idx = bu.js("""(()=>{var rows=Array.from(document.querySelectorAll('tbody tr'));
            var tgt=%s;
            for(var i=0;i<rows.length;i++){
              var c=rows[i].querySelector('.cell'), b=rows[i].querySelector('button');
              if(!c||!b) continue;
              if(c.textContent.replace(/\\s+/g,'').trim().indexOf(tgt)===0
                 && b.textContent.indexOf('去作业')>=0) return i;
            } return -1;})()""" % json.dumps(t))
        if int(idx) >= 0:
            bu.js("(()=>{var r=document.querySelectorAll('tbody tr')[%d];"
                  "r.querySelector('button').click(); return 1;})()" % int(idx))
            time.sleep(3)
            bu.wait_for_element(".questiono-item", visible=True, timeout=15)
            return True
    return False
```

## 3. 选项点击（原生优先，JS 兜底）

```python
def click_opt(kind, i, queue):
    sel = "input[type=radio]" if kind == 'r' else "input[type=checkbox]"
    try:
        ref = queue[i]
        bu.scroll_into_view(ref)
        time.sleep(0.15)
        bu.click(ref)
    except Exception:
        bu.js("(()=>{var e=document.querySelectorAll('.questiono-item %s')[%d];"
              "if(!e) return 0; var l=e.closest('label'); (l||e).click(); return 1;})()" % (sel, i))
```

## 4. 一份作业的完整动作

`spec` 是答案规格列表，每项为 `('s', 选项数, 'B')` / `('m', 选项数, 'ABD')` / `('f', 空位数, ['答案1','答案2'])`，顺序与页面题目顺序一致。

```python
def do_one(title, spec):
    if not open_a(title):
        return title + " OPEN_FAIL"
    snap = parse_snap(bu.snapshot(within=bu.css("main", match="first"),
                                 view="interactive", max_chars=30000))
    radios = [r for r, t, v in snap if t == "radio"]
    checks = [r for r, t, v in snap if t == "checkbox"]
    texts  = [r for r, t, v in snap if t == "textbox"]
    sub    = [r for r, t, v in snap if t == "button" and "提交" in v]

    dom = dict(r=len(radios), c=len(checks), t=len(texts))
    exp = dict(r=sum(k for t, k, v in spec if t == 's'),
               c=sum(k for t, k, v in spec if t == 'm'),
               t=sum(k for t, k, v in spec if t == 'f'))
    if dom != exp:                      # 题型识别错了，别硬填
        return title + " COUNT_MISMATCH dom=%s exp=%s" % (dom, exp)

    ri = ci = ti = 0
    for typ, k, val in spec:
        if typ == 's':
            click_opt('r', ri + ord(val) - 65, radios); ri += k
        elif typ == 'm':
            for L in val:
                click_opt('c', ci + ord(L) - 65, checks)
            ci += k
        else:
            for j, v in enumerate(val):
                bu.type(texts[ti + j], v, submit=False)
            ti += k

    time.sleep(0.6)

    # 提交前空值断言：填空框不允许静默留空（spec 显式给 '' 才视为有意留空）
    blanks = bu.js("""(()=>{var its=document.querySelectorAll('.questiono-item');
      var out=[]; its.forEach(function(it,qi){
        var ins=[...it.querySelectorAll('input.el-input__inner, input[type=text]')];
        ins.forEach(function(inp,j){ if((inp.value||'').trim()==='') out.push(qi+':'+j); });
      }); return JSON.stringify(out);})()""")
    blank_list = json.loads(blanks) if blanks else []
    intentional = [j for typ,k,val in spec if typ=='f' for j,v in enumerate(val) if (v or '').strip()=='']
    real_blank = [b for b in blank_list if int(b.split(':')[1]) not in intentional]
    if real_blank:
        return title + " BLANK_FILL: " + ",".join(real_blank)

    if not sub:
        return title + " NO_SUBMIT"

    try:
        bu.click(sub[0])
    except Exception:
        bu.js("(()=>{var bs=Array.from(document.querySelectorAll('button'));"
              "for(var i=0;i<bs.length;i++){if(bs[i].innerText.trim()==='提交'){bs[i].click(); return 1;}}"
              "return 0;})()")
    time.sleep(2.5)

    msg = bu.js("(()=>{var m=Array.from(document.querySelectorAll('.el-message'))"
                ".map(function(e){return e.innerText.trim();}); return m.join('|');})()")
    if msg and '未提交' in msg:          # 有题漏答，逐项补点后重提
        return title + " INCOMPLETE: " + msg

    r = bu.js("(()=>{var ds=Array.from(document.querySelectorAll('.el-message-box'));"
              "if(!ds.length) return 'nodialog';"
              "var bs=ds[0].querySelectorAll('button');"
              "for(var i=0;i<bs.length;i++){if(bs[i].innerText.trim()==='确定'){bs[i].click(); return 'ok';}}"
              "return 'no_confirm';})()")
    time.sleep(3)
    return title + " -> " + str(r)
```

批量跑时按 4~5 份一组，单次单元格控制在 3 分钟内；每份结束加 `flush=True` 打日志，出错也不至于全丢。

## 5. 漏答兜底（配合第 4 节的 INCOMPLETE）

```python
# 对第 qi 题（0 基）按答案字母逐个点，每次间隔 0.6s
for L in 'ABCD':
    bu.js("""(()=>{var it=document.querySelectorAll('.questiono-item')[%d];
        var e=it.querySelector('input[value="%s"]'); if(!e) return 0;
        var l=e.closest('label'); (l||e).click(); return 1;})()""" % (qi, L))
    time.sleep(0.6)

# 复查：is-checked 才是模型真实状态
bu.js("""(()=>{var it=document.querySelectorAll('.questiono-item')[%d];
    return JSON.stringify(Array.from(it.querySelectorAll('label'))
      .map(function(l){return l.classList.contains('is-checked')?'Y':'N';}));})()""" % qi)
```

## 6. 核验与汇总

```python
def dump_rows():
    return bu.js("""(()=>{var rows=Array.from(document.querySelectorAll('tbody tr'));
      var out=[], seen={};
      rows.forEach(function(r){var c=r.querySelectorAll('.cell'); if(!c.length) return;
        var name=c[0].textContent.replace(/\\s+/g,'').trim().split('-副本')[0];
        var score=c[3]?c[3].textContent.replace(/\\s+/g,' ').trim():'';
        var b=r.querySelector('button'); var bt=b?b.textContent.trim():'';
        if(!name) return; var key=name+'|'+score+'|'+bt; if(seen[key]) return; seen[key]=1;
        out.push(name+' | '+score+' | '+bt);});
      return JSON.stringify(out);})()""")
```

- 同名副本会被去重，**统计总数时要自己加上重复份**，或改用逐行不排重的原始数组。
- 判定完成的标准：所有页里 `去作业` 条目数 = 0。
- 得分读第 4 列（`c[3]`），形如 `5.2/10.0`；`--/10.0` 表示未提交。

### 6.1 结果页回读校验（提交后必做，抓漏填空）

结果页答案块真实 class 是 `.common_test_answer`（**不是** `.common_test_myanswer`，后者取不到答案会把漏填误判成已填）。从列表点进行内按钮进结果页后，逐题解析我的答案，空串位置即漏填：

```python
def read_result():
    return json.loads(bu.js(r"""(()=>{
      function txt(el){return (el?el.textContent:'').replace(/\s+/g,' ').trim();}
      var items=[...document.querySelectorAll('.questiono-item')];
      var qs=items.map(function(it){
        var ansEl=it.querySelector('.common_test_answer');
        var ans=txt(ansEl);
        var m=ans.match(/我的答案:\s*(.*?)(?:\s+得分:|$)/);
        var ansVal=m?m[1].trim():'';
        var hasR=it.querySelector('input[type=radio]')!=null;
        var hasC=it.querySelector('input[type=checkbox]')!=null;
        var type=hasR?'单选':hasC?'多选':'填空';
        var arr=ansVal?ansVal.replace(/^\[|\]$/g,'').split(',').map(s=>s.trim()):[];
        var empty=arr.filter(a=>a==='').length;
        return {type:type, ans:ansVal, empty:empty};
      });
      return JSON.stringify({qs:qs});
    })()"""))

# 任一题 empty>0 即记入 CHECK；填空全空显示 [, , , ]，部分漏填显示 [局部, , , ]
```

### 6.2 回读与题库比对（Gate-3：CHECK / WRONG 分级）

`spec` 里填空期望值列表 `exp_fill`、客观题期望字母 `exp_obj`。回读结果逐题比对：空串 → `CHECK`；非空但与题库不符 → `WRONG`；一致 → `OK`。

```python
def verify_against_bank(spec):
    res = read_result()["qs"]
    report = []
    fi = oi = 0
    for q, (typ, k, val) in zip(res, spec):
        if typ == 'f':
            ans = q["ans"].strip().lstrip('[').rstrip(']')
            got = [x.strip() for x in ans.split(',')]
            if any(x == '' for x in got):
                report.append(("CHECK", q["type"], q["ans"]))
            elif [str(x) for x in val] != got:
                report.append(("WRONG", q["type"], f"got={got} exp={val}"))
            else:
                report.append(("OK", q["type"], q["ans"]))
            fi += k
        else:
            if q["ans"].replace(' ', '') != val:
                report.append(("WRONG", q["type"], f"got={q['ans']} exp={val}"))
            else:
                report.append(("OK", q["type"], q["ans"]))
            oi += k
    return report
# 只读态(状态1/2)出现 CHECK/WRONG 不可改，记入「待老师退回」清单上报；可编辑态(0/3)回 do 页补填
```

### 6.3 整批复盘（Gate-4：漏填 / 错题存疑 / 待批三清单）

对每份结果页跑 `read_result()`，汇总三类；得分列为空的填空份单独进「待批」，不计答错。

```python
def batch_review():
    blank, wrong, pending = [], [], []
    # 逐份 open_result(title) 后：
    for r in read_result()["qs"]:
        if r["empty"] > 0:
            blank.append(r)
        # 与题库不符的在此并入 wrong（配合 6.2 的 WRONG 记录）
    # 列表 dump_rows() 得分列含 '--' 或纯填空得分空 → pending
    return {"blank": blank, "wrong": wrong, "pending": pending}
```

- 汇报必须输出：每份标题 / 题型数 / 已填 / 漏填 / 回读状态 / 得分 / 备注；分清自动判分与人工批阅。

## 7. 已核验的 DOM 事实（省去重新试探）

| 现象 | 结论 |
| --- | --- |
| 默认 `snapshot(within="viewport")` | 只返回视口内控件，长卷丢题 |
| 一个 JS 里连点 3 个 checkbox | 只记最后一个；`input.checked` 仍全 true，`label.is-checked` 才可信 |
| `rows[i].querySelector('button').innerText` | 操作列 `is-hidden`，`innerText` 为空，必须用 `textContent` |
| 直连 `/homework/do/<id>` | 缺 `classId` → 空壳页 |
| 提交后不点弹窗「确定」 | 页面停在答题页，作业仍未提交 |
| 提交成功 | 自动回列表，该行按钮变「已提交」 |
| 结果页「题目解析」 | 恒为空，不含正确答案 |
| 结果页答案块 class | `.common_test_answer`；`.common_test_myanswer` 取不到答案，会把漏填空误判成已填 |
| 填空漏填回显 | `[, , , ]` 全空；`[局部, , , ]` 部分漏填；逗号是数组分隔符，不是答案内容 |
| 已提交作业能否重做 | 列表行内只有「已提交」标签；状态筛「撤回重做」为空时，本份不可撤回；直连 do 页是空壳，只能等老师开放或联系任课教师 |

# 可复用实现（已实测通过）

以下代码全部在 `computer_use_tool(plane="bu")` 单元格内运行，`import aha_browser_use as bu`。`cell` 每次都是新进程，所以每次都要把 helper 一起带上。

## 0. 常量

```python
LIST = "https://www.zjooc.cn/ucenter/student/course/study/<courseId>/homework"
```

## 1. 解析快照为 ref 队列

```python
import re
def parse_snap(s):
    out = []
    for line in str(s).splitlines():
        m = re.match(r'^\s*(n\d+)\s+(radio|checkbox|textbox|button)\s+"(.*)"', line)
        if m:
            out.append((m.group(1), m.group(2), m.group(3)))
    return out

snap = parse_snap(bu.snapshot(within=bu.css("main", match="first"),
                             view="interactive", max_chars=30000))
radios = [r for r, t, v in snap if t == "radio"]
checks = [r for r, t, v in snap if t == "checkbox"]
texts  = [r for r, t, v in snap if t == "textbox"]
sub    = [r for r, t, v in snap if t == "button" and "提交" in v]
```

## 2. 定位并打开某份作业（幂等）

标题只在 `-副本` 之前有效，比较时去掉所有空白，并只做前缀匹配。

```python
import time, json
def norm(s):
    return re.sub(r'\s+', '', s or '')

def open_a(title):
    t = norm(title)
    for page in (1, 2, 3):
        bu.navigate(LIST)
        bu.wait_for_load(timeout=15)
        bu.wait_for_element("tbody tr", visible=True, timeout=15)
        if page > 1:
            bu.js("(()=>{var n=document.querySelectorAll('.el-pager li.number');"
                  "var k=%d; if(n.length>k){n[k].click(); return 1;} return 0;})()" % (page - 1))
            time.sleep(2)
        idx = bu.js("""(()=>{var rows=Array.from(document.querySelectorAll('tbody tr'));
            var tgt=%s;
            for(var i=0;i<rows.length;i++){
              var c=rows[i].querySelector('.cell'), b=rows[i].querySelector('button');
              if(!c||!b) continue;
              if(c.textContent.replace(/\\s+/g,'').trim().indexOf(tgt)===0
                 && b.textContent.indexOf('去作业')>=0) return i;
            } return -1;})()""" % json.dumps(t))
        if int(idx) >= 0:
            bu.js("(()=>{var r=document.querySelectorAll('tbody tr')[%d];"
                  "r.querySelector('button').click(); return 1;})()" % int(idx))
            time.sleep(3)
            bu.wait_for_element(".questiono-item", visible=True, timeout=15)
            return True
    return False
```

## 3. 选项点击（原生优先，JS 兜底）

```python
def click_opt(kind, i, queue):
    sel = "input[type=radio]" if kind == 'r' else "input[type=checkbox]"
    try:
        ref = queue[i]
        bu.scroll_into_view(ref)
        time.sleep(0.15)
        bu.click(ref)
    except Exception:
        bu.js("(()=>{var e=document.querySelectorAll('.questiono-item %s')[%d];"
              "if(!e) return 0; var l=e.closest('label'); (l||e).click(); return 1;})()" % (sel, i))
```

## 4. 一份作业的完整动作

`spec` 是答案规格列表，每项为 `('s', 选项数, 'B')` / `('m', 选项数, 'ABD')` / `('f', 空位数, ['答案1','答案2'])`，顺序与页面题目顺序一致。

```python
def do_one(title, spec):
    if not open_a(title):
        return title + " OPEN_FAIL"
    snap = parse_snap(bu.snapshot(within=bu.css("main", match="first"),
                                 view="interactive", max_chars=30000))
    radios = [r for r, t, v in snap if t == "radio"]
    checks = [r for r, t, v in snap if t == "checkbox"]
    texts  = [r for r, t, v in snap if t == "textbox"]
    sub    = [r for r, t, v in snap if t == "button" and "提交" in v]

    dom = dict(r=len(radios), c=len(checks), t=len(texts))
    exp = dict(r=sum(k for t, k, v in spec if t == 's'),
               c=sum(k for t, k, v in spec if t == 'm'),
               t=sum(k for t, k, v in spec if t == 'f'))
    if dom != exp:                      # 题型识别错了，别硬填
        return title + " COUNT_MISMATCH dom=%s exp=%s" % (dom, exp)

    ri = ci = ti = 0
    for typ, k, val in spec:
        if typ == 's':
            click_opt('r', ri + ord(val) - 65, radios); ri += k
        elif typ == 'm':
            for L in val:
                click_opt('c', ci + ord(L) - 65, checks)
            ci += k
        else:
            for j, v in enumerate(val):
                bu.type(texts[ti + j], v, submit=False)
            ti += k

    time.sleep(0.6)
    if not sub:
        return title + " NO_SUBMIT"

    try:
        bu.click(sub[0])
    except Exception:
        bu.js("(()=>{var bs=Array.from(document.querySelectorAll('button'));"
              "for(var i=0;i<bs.length;i++){if(bs[i].innerText.trim()==='提交'){bs[i].click(); return 1;}}"
              "return 0;})()")
    time.sleep(2.5)

    msg = bu.js("(()=>{var m=Array.from(document.querySelectorAll('.el-message'))"
                ".map(function(e){return e.innerText.trim();}); return m.join('|');})()")
    if msg and '未提交' in msg:          # 有题漏答，逐项补点后重提
        return title + " INCOMPLETE: " + msg

    r = bu.js("(()=>{var ds=Array.from(document.querySelectorAll('.el-message-box'));"
              "if(!ds.length) return 'nodialog';"
              "var bs=ds[0].querySelectorAll('button');"
              "for(var i=0;i<bs.length;i++){if(bs[i].innerText.trim()==='确定'){bs[i].click(); return 'ok';}}"
              "return 'no_confirm';})()")
    time.sleep(3)
    return title + " -> " + str(r)
```

批量跑时按 4~5 份一组，单次单元格控制在 3 分钟内；每份结束加 `flush=True` 打日志，出错也不至于全丢。

## 5. 漏答兜底（配合第 4 节的 INCOMPLETE）

```python
# 对第 qi 题（0 基）按答案字母逐个点，每次间隔 0.6s
for L in 'ABCD':
    bu.js("""(()=>{var it=document.querySelectorAll('.questiono-item')[%d];
        var e=it.querySelector('input[value="%s"]'); if(!e) return 0;
        var l=e.closest('label'); (l||e).click(); return 1;})()""" % (qi, L))
    time.sleep(0.6)

# 复查：is-checked 才是模型真实状态
bu.js("""(()=>{var it=document.querySelectorAll('.questiono-item')[%d];
    return JSON.stringify(Array.from(it.querySelectorAll('label'))
      .map(function(l){return l.classList.contains('is-checked')?'Y':'N';}));})()""" % qi)
```

## 6. 核验与汇总

```python
def dump_rows():
    return bu.js("""(()=>{var rows=Array.from(document.querySelectorAll('tbody tr'));
      var out=[], seen={};
      rows.forEach(function(r){var c=r.querySelectorAll('.cell'); if(!c.length) return;
        var name=c[0].textContent.replace(/\\s+/g,'').trim().split('-副本')[0];
        var score=c[3]?c[3].textContent.replace(/\\s+/g,' ').trim():'';
        var b=r.querySelector('button'); var bt=b?b.textContent.trim():'';
        if(!name) return; var key=name+'|'+score+'|'+bt; if(seen[key]) return; seen[key]=1;
        out.push(name+' | '+score+' | '+bt);});
      return JSON.stringify(out);})()""")
```

- 同名副本会被去重，**统计总数时要自己加上重复份**，或改用逐行不排重的原始数组。
- 判定完成的标准：所有页里 `去作业` 条目数 = 0。
- 得分读第 4 列（`c[3]`），形如 `5.2/10.0`；`--/10.0` 表示未提交。

## 7. 已核验的 DOM 事实（省去重新试探）

| 现象 | 结论 |
| --- | --- |
| 默认 `snapshot(within="viewport")` | 只返回视口内控件，长卷丢题 |
| 一个 JS 里连点 3 个 checkbox | 只记最后一个；`input.checked` 仍全 true，`label.is-checked` 才可信 |
| `rows[i].querySelector('button').innerText` | 操作列 `is-hidden`，`innerText` 为空，必须用 `textContent` |
| 直连 `/homework/do/<id>` | 缺 `classId` → 空壳页 |
| 提交后不点弹窗「确定」 | 页面停在答题页，作业仍未提交 |
| 提交成功 | 自动回列表，该行按钮变「已提交」 |
| 结果页「题目解析」 | 恒为空，不含正确答案 |

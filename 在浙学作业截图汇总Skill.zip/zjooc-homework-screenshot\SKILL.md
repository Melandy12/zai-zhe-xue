---
name: zjooc-homework-screenshot
description: 在浙江省高等学校在线开放课程共享平台（zjooc.cn，又称「在浙学」）逐份打开作业批改结果详情页，把每份作业的整页（标题、学生、每题题干/分值/我的答案/每题得分）截成真实页面长图，按「姓名_班级_学号_作业名」命名，汇总成一份 Word 交付。当用户要求「把每份作业结果页都截图给我」「作业完成情况截图要含每道题」「结果详情页整页截图汇总成 Word」，或给出 www.zjooc.cn/ucenter/student/course/.../homework 链接时使用。只做结果页截图汇总，不作答提交（用 zjooc-homework-runner）、不回讨论帖（用 zjooc-discuss-replier）。
---

# 在浙学（zjooc）作业结果详情页整页截图汇总

用 Browser Use（`computer_use_tool` + `plane="bu"` + `import aha_browser_use as bu`）操作真实页面。截图必须是**真实页面视口截图**，禁止用 PIL/matplotlib 自绘表格或题目图代替网页截图。

## 前置条件

1. `bu.navigate` 打开作业列表，读 `bu.get_page_text()`：右上角出现学生姓名即已登录；出现「请登录」立即 `interaction.request_action`（`type="browserControl"`）交接，不代填账号密码、不绕过验证码/扫码。
2. **登录页验证码被右边缘裁切的标准处理（反复出现，必须先做再交接）**：本浏览器视口宽约 759，登录表单固定在右侧、验证码图片贴在验证码输入框右边，默认常被裁掉。交接前先 `document.body.style.zoom='0.68'` 缩小整页，再读验证码元素（`.forms code`）的 `getBoundingClientRect()`，确认 `right <= innerWidth`、彩色字符完整可见；若仍溢出，继续下调 zoom 到 0.6 左右。不要只靠"把浏览器往右移"——视口宽度固定，右移无法让溢出元素入屏，只能缩放或横向滚动。
3. 不登出浏览器里其他任务正在使用的会话；登录态以页面顶部账号名与结果页「学生:xxx」字段为准。
4. 本地 Python 用带 PIL 与 python-docx 的解释器（本环境 `C:\Users\MECHREVO\miniconda3\python.exe`，PIL 12.x、python-docx 1.2.x）；沙箱自带 `python` 可能缺 PIL，不要混用。

## 硬性约束（实测踩坑，违反就截不到整份作业）

1. **逐份进结果详情页，不截列表页代替**：用户明确要求每张图含每道题的题干、我的答案、得分。列表页只有分数/状态，不满足；必须从作业列表点行内「已提交/已批阅」按钮进入 `/homework/result/<paperId>/processStatus/1`。
2. **结果页直链会被会话拦回课程列表**：新开标签或直接 navigate 结果页 URL 会跳回 `/ucenter/student/course/build/list`；只能从列表点行内按钮进入。`study/<courseId>/homework` 路径也可能被重定向到 `build/homework`（旧版我的作业入口），以实际落地页为准。
3. **整页 beyond-viewport 截图在本浏览器必白屏**：`Page.captureScreenshot(captureBeyondViewport=True, clip=整页高度)` 实测返回全白帧；可行做法是**按视口高度纵向分段截视口图，再本地用 PIL 纵向拼接**。
4. **分段截图必须逐段滚动 + 检测白屏**：
   - 先量 `scrollHeight` 与 `innerHeight`，步长 = 视口高，算出 `[0, vh, 2vh, …]` 各段起点。
   - 每段 `window.scrollTo(0, y)` 后 `time.sleep(0.6)` 再 `bu.screenshot(with_cursor=False)`，复制落盘。
   - 白屏判定：单段文件 < 15KB 视为白帧；先 `bu.resync()` 重取附着、等待 1.2s 后重截一次；仍白则记录到 `CHECK` 清单，不要反复在卡死标签上重试。
5. **首屏最容易白屏**：进入结果页后的第一段（scrollY=0）白屏概率最高；`bu.resync()` 通常可恢复首屏，恢复后再继续分段。
6. **列表 20 条/页，跨页行索引会漂移**：默认分页只显示前 20 条；第 21 份起要先点 `.el-pager li.number` 第 2 页，再用**第二页本地序号**点击，不能沿用第一页全局索引。
7. **行内按钮是 Vue 绑定、无 href、无 onclick**：必须限定 `tbody tr` 内按钮（直接 `querySelector('button')` 会命中顶部「身份切换」）。点击优先走 **CDP `Runtime.evaluate` 里 `b.click()`**；`bu.click_xy` 坐标点击常被按钮文字 span 或右侧悬浮客服层遮挡而不跳转，`bu.click(css locator)` 报 `BU_TARGET_OBSCURED` 时也改走 CDP。
8. **校验用「结果页标题 + 学生姓名」，不要只认 URL 里的 paperId**：不同账号、不同作业的 paperId 可能撞号（与另一账号某份编号相同），URL pid 一致不代表没跳错。进入结果页后比对页面标题与清单标题、`学生:xxx` 与目标账号一致，才算 MATCH；错位即中止该份。
9. **同名作业文件名要加序号后缀**：不同作业标题可能完全相同（如两份「第二章（4）-副本(01)-副本(01)」）；同名第二份起文件名追加 `-2`、`-3`，避免互相覆盖。文件名清理 Windows 非法字符 `\ / : * ? " < > |`。
10. **分段拼接用逐行去重，不要用固定像素重叠**：固定 30–60px 重叠要么残留重复题行、要么裁掉题干行；改为比对上一段底部与下一段顶部的图像行（灰度差小于阈值判为重复行），按重复行起始偏移裁剪下一段，再白底纵向粘贴。
11. **末段起点不要取滚动上限 `max` 本身，取 `max - vh`**：`max = body.scrollHeight - innerHeight`。末段若 `scrollTo(0, max)`，视口下沿贴内容底、上沿只比上一段低 `max - 上一段起点`，常出现 150px 左右重叠；若取 `max - vh`，末段视口上沿贴内容底向上回看，重叠最小。注意 `documentElement.scrollHeight` 与 `body.scrollHeight` 不一致时，可滚上限以 `body.scrollHeight - innerHeight` 为准。
12. **整屏重复段要整段丢弃，不要硬裁**：长作业（3 段）末段常把上一段底部已完整出现的多选/不定项题卡再整屏重复一遍。去重时按深色内容行（灰度<120 的像素计数）做模板匹配：若最佳对齐仍落在头部留白区（偏移低于内容题卡出现位置，实测约 110px），说明该段是纯重复屏，直接整段跳过（不拼接）；只有对齐到真实内容行时才按偏移裁剪保留。留白行不参与比对，避免空白把模板匹配带到留白带而误判。

## 标准流程

### 1. 建立清单并落盘

进入作业列表（必要时切分页），遍历 `tbody tr` 去重（主表 + 固定列各一份，按整行文本判重），每行取：序号 `i`、标题、得分、状态。逐份点进行内按钮，从跳转后 URL 取 `paperId`。落盘 `result_pids.json`，每项 `{i, pid, stu, title, score, status}`；`homework_rows.json` 存原始列表行备查。

### 2. 逐份分段截图

对清单每份：
- 回列表（第 21 份起先翻第 2 页），按本地序号点行内按钮进结果页；
- 读 URL 校验 `paperId` 与清单一致；
- 量整页高度 → 分段滚动截图 → 每段落盘到独立子目录 `_seg_work/p<i>/seg_0.png, seg_1.png, …`（独立子目录避免跨份覆盖）；
- 记录每份段数与最小段大小，最小段 < 15KB 标 `CHECK`。

### 3. 本地拼接整页长图

用 PIL 把同份分段图纵向拼接：统一宽度（取最窄段宽，其余等比缩放），段间重叠 30px 去掉重复题行；白底画布自上而下粘贴。成品命名：`姓名_班级_学号_作业名.png`（同名追加 `-2`）。

### 4. 生成汇总 Word

- **Word 文件名按 `姓名_班级_学号.docx` 命名**（如 `<姓名>_<班级>_<学号>.docx`），不要用课程名/作业汇总作文件名；
- 封面：课程名、姓名/班级/学号、作业份数、口径说明（「已提交」为待老师批阅，填空暂未给分不等于答错）；
- 按清单顺序，每份一段小标题（序号 + 作业名 + 得分 + 状态），下方居中嵌入对应整页长图，按页宽等比缩放；
- 交付前不回读校验、不转 PDF；产物用 `present_files` 交付，`name` 带 `.docx` 后缀。
- 若 docx 被桌面 Word/WPS 占用无法改名，先提示用户关闭已打开的文档，再重命名，不要强杀进程。

## 判分口径（写说明与汇报时必须说清）

- 单选、多选自动判分；多选按选对选项数给部分分，会出现 0.5、0.7 类分值。
- **填空题由老师人工批阅**，提交后得分列为空或 0；整份全填空时显示 `0/10` 不等于答错，只是还没批。
- 状态区分「已批阅」（已给分）与「已提交」（待批）。结果页只给「我的答案 + 得分」，不给正确答案。

## 已核验 DOM 事实与坑位

| 现象 | 结论 |
| --- | --- |
| 结果页直链 / study 路径被拦回 `build/list` 或 `build/homework` | 会话拦截；只能从列表点行内按钮进入结果页 |
| `Page.captureScreenshot(beyondViewport=整页)` 全白 | 全页截图通道在本浏览器失效；改分段视口截图 + 本地 PIL 拼接 |
| 进入结果页首屏白屏、滚动后段正常 | 首屏最易白；`bu.resync()` 恢复后重截首屏 |
| 单段文件 < 15KB 白帧 | resync 重截一次；仍白记入 CHECK，不在卡死标签反复重试 |
| `querySelector('button')` 点到「身份切换」 | 按钮在 `tbody tr` 内；Vue 绑定无 href/onclick，优先 CDP `b.click()`；坐标点击被文字 span/客服浮层遮挡时不跳转 |
| 跳转后 URL 的 paperId 与清单一致却跳错 | 不同账号/作业 pid 会撞号；必须用结果页标题 + `学生:xxx` 双重校验 |
| 两份作业标题完全相同 | 成品文件名追加 `-2`、`-3`，避免覆盖 |
| 固定像素重叠拼接残留重复行/裁掉题干 | 改为逐行图像比对去重（灰度差阈值），按重复行偏移裁剪下一段 |
| 末段 `scrollTo(0,max)` 与上段重叠约 150px、题卡重复 | 末段起点取 `max - vh`；可滚上限以 `body.scrollHeight - innerHeight` 为准 |
| 长作业末段整屏重复多选/不定项题卡 | 按深色内容行模板匹配；对齐落在头部留白区（<约110px）判为纯重复屏，整段丢弃，不硬裁 |
| 行内 `td.is-hidden` 按钮 `innerText` 为空 | 判文案用 `textContent` |
| 沙箱 `python` 缺 PIL | 拼接/Word 用 miniconda 解释器；不做本地绘图代替网页截图 |
| 登录/扫码/验证码卡点 | 必须 `browserControl` 交接；不代填、不绕过、不重试 |
| 登录页验证码被右边缘裁掉 | 视口宽约 759、表单固定右侧；先 `body.style.zoom=0.68`（必要时 0.6），读 `.forms code` 的 rect 确认 right≤innerWidth；右移浏览器无效，只能缩放/横滚 |

## 参考资料

- `references/browser-recipes.md`：登录态校验、清单抓取、分段截图、PIL 拼接、Word 生成的可粘贴脚本与已核验选择器。

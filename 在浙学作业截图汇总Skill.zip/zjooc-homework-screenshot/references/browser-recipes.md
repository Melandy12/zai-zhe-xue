# 作业结果页整页截图：可复用脚本（已实测通过）

以下浏览器脚本在 `computer_use_tool(plane="bu")` 单元格内运行，`import aha_browser_use as bu`；本地拼接/Word 脚本用 miniconda Python 运行。每个 cell 都是新进程，helper 随代码带上。

## 0. 常量

```python
COURSE = "8a22121fa079852501a08b122a31424c"
LIST_BUILD = "https://www.zjooc.cn/ucenter/student/course/build/homework"
LIST_STUDY = f"https://www.zjooc.cn/ucenter/student/course/study/{COURSE}/homework"
RESULT = f"https://www.zjooc.cn/ucenter/student/course/study/{COURSE}/homework/result/{pid}/processStatus/1"
STU, CLS, SID = "朱文静", "材料4", "2500501405"
```

## 1. 登录态校验

```python
import time, json
def check_login():
    return bu.js("""(()=>{
      var t=document.body.textContent||'';
      var logged=/退出|我的课程|我的作业|我的讨论/.test(t) && !/请登录|登录后查看/.test(t);
      return JSON.stringify({logged:!!logged});
    })()""")
```

未登录即 `interaction.request_action(type="browserControl", ...)` 交接；不代填、不绕过。

## 2. 抓清单（标题/得分/状态）并取 paperId

列表默认 20 条/页。`tbody tr` 主表 + 固定列各一份，按整行文本去重。

```python
def open_list(page=1):
    bu.navigate(LIST_BUILD); bu.wait_for_load(timeout=10); time.sleep(1.0)
    if page == 2:
        bu.js("""(function(){var n=[...document.querySelectorAll('.el-pager li.number')]; if(n.length>=2) n[1].click();})()""")
        time.sleep(1.2)

def click_local(local):
    bu.js(f"""(function(){{
      var seen=new Set(),rows=[];
      [...document.querySelectorAll('tbody tr')].forEach(function(tr){{
        var t=tr.textContent; if(seen.has(t))return; seen.add(t); rows.push(tr);
      }});
      var tr=rows[{local}]; var b=tr&&tr.querySelector('button');
      if(b)['mousedown','mouseup','click'].forEach(function(t){{
        b.dispatchEvent(new MouseEvent(t,{{bubbles:true,cancelable:true,view:window}}));
      }});
    }})()""")
    time.sleep(2.0)

def current_pid():
    url=bu.page_info().get("url","")
    return url.split("/result/")[1].split("/")[0] if "/result/" in url else ""
```

- 第一页本地序号 0..19，第二页本地序号 0..8（对应清单 i=20..28）。
- 每份点完比对 `current_pid()` 与清单 `pid`，不一致（MISMATCH）即中止该份，不要硬截。

## 3. 分段截图（白屏自动 resync 重截）

```python
import os, shutil, json
def shoot_segments(segdir):
    os.makedirs(segdir, exist_ok=True)
    g=json.loads(bu.js("JSON.stringify({dh:document.documentElement.scrollHeight, vh:innerHeight})"))
    steps=[]; y=0
    while y < g["dh"]:
        steps.append(y); y+=g["vh"]
    sizes=[]
    for idx,y in enumerate(steps):
        bu.js(f"window.scrollTo(0,{y})"); time.sleep(0.6)
        p=os.path.join(segdir,f"seg_{idx}.png")
        f=bu.screenshot(with_cursor=False); shutil.copy(f.path,p); sz=os.path.getsize(p)
        if sz < 15000:                      # 白帧
            bu.resync(); time.sleep(1.2)
            f=bu.screenshot(with_cursor=False); shutil.copy(f.path,p); sz=os.path.getsize(p)
        sizes.append(sz)
    return g["dh"], sizes
```

- 每段落独立子目录 `_seg_work/p<i>/`，避免跨份覆盖。
- 最小段 < 15000 记入 CHECK；不要在卡死标签上反复重试。

## 4. 本地 PIL 拼接整页长图

```python
import glob, re
from PIL import Image

def stitch(segdir, out, overlap=30):
    files=sorted(glob.glob(os.path.join(segdir,"seg_*.png")),
                 key=lambda p:int(re.search(r"_(\d+)\.png$",p).group(1)))
    imgs=[Image.open(f).convert("RGB") for f in files]
    w=min(i.width for i in imgs)
    imgs=[i.resize((w,int(i.height*w/i.width))) if i.width!=w else i for i in imgs]
    total=sum(i.height for i in imgs)-overlap*(len(imgs)-1)
    canvas=Image.new("RGB",(w,total),"white")
    y=0
    for k,im in enumerate(imgs):
        if k==0: canvas.paste(im,(0,0)); y=im.height
        else: y-=overlap; canvas.paste(im,(0,y)); y+=im.height-overlap
    canvas.save(out)
```

文件名：`{STU}_{CLS}_{SID}_{safe(title)}.png`；`safe` 去掉 `\ / : * ? " < > |`。同名第二份起追加 `-2`、`-3`。

## 5. 生成汇总 Word（python-docx）

- 封面：课程名 + 姓名/班级/学号 + 份数 + 口径说明（已提交=待批，填空 0 分不等于答错）。
- 按清单顺序：小标题（序号 + 标题 + 得分 + 状态）→ 居中嵌入整页长图，`width=Inches(6.0)` 等比缩放。
- 不回读校验、不转 PDF；交付 `present_files`，`name` 带 `.docx`。

## 6. 已核验 DOM / 路径事实

| 项 | 事实 |
| --- | --- |
| 结果页 URL | `.../homework/result/<paperId>/processStatus/1`（个别 `processStatus/2`） |
| 列表落地页 | 旧版 `/build/homework`（我的作业）；`study/.../homework` 可能被重定向至此 |
| 题目块 | `.questiono-item`；题干 `.questiono-header`；我的答案 `.common_test_myanswer`；得分 `.common_test_score` |
| 题型分组 | 单选题/多选题/填空题/不定项选择题，按文本分区呈现 |
| 行内按钮 | `tbody tr` 内 `button.el-button--default`，Vue 绑定，无 href/onclick，需派发鼠标事件 |
| 分页 | `.el-pager li.number`；默认 20 条/页 |
| 白帧大小阈值 | < 15KB；首屏最易白，`bu.resync()` 可恢复 |
| 全页截图 | `captureBeyondViewport=True` 在本浏览器返回白帧，不可用 |

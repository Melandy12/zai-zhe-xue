# 在浙学（zjooc）视频倍速刷课 Skill 总说明

> 适用平台：浙江省高等学校在线开放课程共享平台（www.zjooc.cn，又称「在浙学」）
> 适用任务：「章节内容」里的视频学习——按完成标记找出没看的章节，倍速静音自动连播到 100%
> 不适用：作业 / 测验 / 考试（另用 `zjooc-homework-runner`）、讨论发帖
> 本文档合并自 Skill 文件夹内的 `SKILL.md` 与 `references/browser-recipes.md`，两个原文件同目录留存。

---

## 一、结论先行

页面没有倍速按钮，但视频底层是标准 HTML5 `video`（blob/MSE），`playbackRate` 可写：

```
v.muted = true; v.playbackRate = 6; v.play();
```

**平台按「内容时长」记账，倍速是真的折算**：本次实测 6 倍速跑约 17 分钟真实时间，「已观看视频」从 04:52:20 增到 07:08:30（+2 小时 16 分，正好等于所看视频的内容时长），学习进度 68% → 100%，视频观看得分 6.8 → 10（满分）。

---

## 二、实测踩过的坑（重点，先看这一节）

| # | 坑 | 现象 | 正确做法 |
|---|---|---|---|
| 1 | 驱动脚本注入错页面 | 在视频详情页算「未看章节」，结果是 0 个，脚本立刻报 `ALL DONE`，实际一节没刷 | 驱动**必须在章节列表页（/plan）注入**；详情页左侧树是另一套结构，没有 `complete` 类 |
| 2 | 按固定下标硬走 | 播放器会自动连播，`duration` 中途突变（843→886），下标和实际节错位 | 每节结束回 /plan，**重新计算第一个未看节点**；完成标记（不是下标）才是唯一真相 |
| 3 | 完成标记有延迟 | 视频 `ended` 后立即回列表，可能还没打勾，又被点开重放一遍 | `ended` 后冷却 10–12 秒再回列表 |
| 4 | 不静音直接 `play()` | `paused` 仍为 true，视频不动；JS 里直接播还可能被自动播放策略拦截 | 先 `v.muted = true`，再设倍速、`play()` |
| 5 | 追求 8 倍速 | 播放器会把倍速重置回 4，实际速度不升反降 | 稳定用 **6 倍速**（已验证能保持并计入） |
| 6 | 想拖进度条刷完 | `currentTime` 能拖、不回弹，但「已观看视频」一动不动，纯浪费时间 | 只能正常播放，不能 seek |
| 7 | 以为「我的答案」那种空壳视频 | 直连 `/plan/detail/<id>` 有时取不到题/视频；要从列表点 | 同样必须从 /plan 树节点点击进入 |
| 8 | 单元格里 `while` 长轮询 | 几分钟后 `COMMAND_TIMEOUT`，脚本被中断 | 把 `setInterval` 驱动**注入页面**，外层只做轻量读取 + `Wait` |
| 9 | 靠截图判断播放 | 详情页截图常是空白帧 | 读 DOM：`video.currentTime / duration / paused / ended` |
| 10 | 分不清左侧目录和正在播放 | 详情页左侧常驻第一章开始的完整目录，看着像「在看第一节」 | 以面包屑「返回章节列表 第五章…」和 URL 里的 detail id 为准 |
| 11 | 文档类节点没视频 | 「课外阅读」是文档（icon-file），点开后一直没有 video | 20 秒等不到 video 就记入 skip，不再重复点 |
| 12 | 只看脚本日志宣布完成 | 日志可能误报 | 回 /plan 数 `DONE=总数 TODO=0`，再到 /progress 复核「我的进度 / 已观看视频 / 上次学到」三处 |

---

## 三、页面与数据口径

| 页面 | 路径 | 作用 |
|---|---|---|
| 章节列表 | `/ucenter/student/course/study/<courseId>/plan` | 唯一有完成标记的地方，注入驱动 |
| 视频页 | `.../plan/detail/<id>` | 播放、拿 `video` 状态 |
| 学习进度 | `/ucenter/student/course/study/<courseId>/progress` | 复核「我的进度」「已观看视频」「上次学到」 |

完成标记（/plan 页 `.el-tree-node__content` 叶子）：

```
已看视频：<i class="complete iconfont icon-shipin">
未看视频：<i class="iconfont icon-shipin">
文档类：  <i class="iconfont icon-file">
```

进度页口径：

- 「我的进度」= 已观看内容时长 / 全部内容时长；
- 「已观看视频」累计按**内容时长**计，6 倍速等效看 6 倍时间（已实测）；
- 「视频观看」是独立得分项（本课满分 10），和作业、测验、考试、讨论、笔记分开；
- 刷完后「上次学到」应是最后一节标题。

---

## 四、标准流程

1. **登录确认**：课程页右上角有学生姓名即可；出现「请登录」则交还给用户本人登录，不代输密码。
2. **列清单**：在 /plan 读所有叶子，列出未看（缺 `complete`）的节点；文档类跳过。
3. **注驱动**：在 /plan 注入 `setInterval` 驱动（代码见下）。
4. **轻量汇报**：每 60–150 秒读一次 `window.__log`，确认当前节、`ct/duration`、倍速率正常。
5. **双重复核**：
   - /plan：`DONE=总数, TODO=0`；
   - /progress：进度 100%、已观看时长到位、「上次学到」=最后一节。

---

## 五、完整驱动脚本（可直接粘贴）

```python
import seed_browser_use as bu

PLAN = "https://www.zjooc.cn/ucenter/student/course/study/<courseId>/plan"

# 1) 列出未看清单（在 /plan 页）
d = bu.js("""(()=>{var cs=document.querySelectorAll('.el-tree-node__content'); var out=[];
for(var i=0;i<cs.length;i++){var c=cs[i]; if(!c.querySelector('.is-leaf')) continue;
 var ic=c.querySelector('i'); var cls=ic?(ic.className||''):'';
 var t=(c.innerText||'').replace(/\\s+/g,'');
 out.push(i+'|'+(cls.indexOf('complete')>=0?'DONE':'TODO')+'|'+(cls.indexOf('shipin')>=0?'video':'doc')+'|'+t.slice(0,20));}
return out.join('\\n');})()""")
print(d)

# 2) 注入驱动（必须在 /plan 页执行）
JS = r"""
(function(){
try{
 var PLAN='https://www.zjooc.cn/ucenter/student/course/study/<courseId>/plan';
 var RATE=6;
 window.__log=[]; window.__start=Date.now(); window.__st='run';
 window.__todo=null; window.__ti=0; window.__cool=0; window.__cur=null;
 function L(m){ window.__log.push(Math.round((Date.now()-window.__start)/1000)+'s '+m);
   if(window.__log.length>400) window.__log.shift(); }
 function onPlan(){ return /\/plan$/.test(location.pathname); }
 function back(){
  var as=document.querySelectorAll('a,span,button,div');
  for(var i=0;i<as.length;i++){ if((as[i].innerText||'').trim()==='返回章节列表'){ as[i].click(); L('back to plan'); return 1; } }
  location.href=PLAN; return 0;
 }
 function computeTodo(){
  var cs=document.querySelectorAll('.el-tree-node__content'); var out=[];
  for(var i=0;i<cs.length;i++){ var c=cs[i]; if(!c.querySelector('.is-leaf')) continue;
   var ic=c.querySelector('i'); var cls=ic?(ic.className||''):'';
   if(cls.indexOf('complete')<0) out.push(i); }
  return out; }
 function doneIdx(i){ var cs=document.querySelectorAll('.el-tree-node__content'); var c=cs[i];
   if(!c) return true; var ic=c.querySelector('i'); return ic && (ic.className||'').indexOf('complete')>=0; }
 function tick(){
  try{
   if(window.__st==='done') return;
   if(Date.now()<window.__cool) return;
   if(window.__st==='run'){
    if(!onPlan()){ back(); window.__cool=Date.now()+5000; return; }
    if(window.__todo===null){ window.__todo=computeTodo(); L('TODO='+window.__todo.join(',')); }
    while(window.__ti<window.__todo.length && doneIdx(window.__todo[window.__ti])){ window.__ti++; }
    if(window.__ti>=window.__todo.length){ window.__st='done'; L('ALL DONE'); return; }
    var i=window.__todo[window.__ti];
    var cs=document.querySelectorAll('.el-tree-node__content'); var c=cs[i];
    window.__cur=(c.innerText||'').replace(/\s+/g,''); window.__t0=Date.now();
    c.click(); window.__st='playing'; L('open '+i+' '+window.__cur); return;
   }
   if(window.__st==='playing'){
    var v=document.querySelector('video');
    if(!v){ if(Date.now()-window.__t0>20000){ L('no video skip'); window.__ti++; window.__st='run'; window.__cool=Date.now()+3000; } return; }
    if(!(v.duration>0)){ if(Date.now()-window.__t0>20000){ L('no meta retry'); window.__st='run'; window.__cool=Date.now()+3000; } return; }
    if(v.ended){ L('END '+Math.round(v.currentTime)+'/'+Math.round(v.duration)+' '+window.__cur);
      window.__ti++; window.__st='run'; window.__cool=Date.now()+10000; return; }
    try{ v.muted=true; }catch(e){}
    try{ if(v.playbackRate<1.05) v.playbackRate=RATE; }catch(e){}
    try{ if(v.paused) v.play(); }catch(e){}
    if(window.__mark!==Math.round(v.currentTime/60)){ window.__mark=Math.round(v.currentTime/60);
      L('at '+Math.round(v.currentTime)+'/'+Math.round(v.duration)+' r='+v.playbackRate+' '+window.__cur); }
   }
  }catch(e){ L('err '+e.message); }
 }
 clearInterval(window.__t); window.__t=setInterval(tick,3000); tick();
 return 'driver installed';
}catch(e){ return 'ERR '+e.message; }
})()
"""
bu.navigate(PLAN)
bu.wait_for_load(timeout=25)
print(bu.js(JS))

# 3) 轻量轮询（外层用 Wait 等 60–150 秒读一次，不要在单元格里循环）
print(bu.js("(()=>{var v=document.querySelector('video'); var s=v?('c='+Math.round(v.currentTime)+'/'+Math.round(v.duration)+' r='+v.playbackRate+' p='+v.paused):'novideo'; return s+' | st='+window.__st+' ti='+window.__ti+' | '+(window.__log||[]).slice(-8).join(' || ');})()"))

# 4) 复核（/plan）
bu.js("""(()=>{var cs=document.querySelectorAll('.el-tree-node__content'); var todo=[],done=0;
for(var i=0;i<cs.length;i++){var c=cs[i]; if(!c.querySelector('.is-leaf')) continue;
 var ic=c.querySelector('i'); var cls=ic?(ic.className||''):'';
 if(cls.indexOf('complete')>=0) done++; else todo.push((c.innerText||'').replace(/\\s+/g,'').slice(0,16));}
return 'DONE='+done+' TODO='+todo.length+(todo.length?(' -> '+todo.join(',')):'');})()""")

# 5) 复核（/progress）
bu.navigate(PLAN.rsplit('/',1)[0] + '/progress')
bu.wait_for_load(timeout=25)
print(bu.get_page_text())
```

## 六、耗时估算

一节 8–14 分钟的视频，6 倍速约 90–140 秒播完。剩余内容时长 = 总时长 ×（100% − 当前进度），除以 6 即大致挂机时间。

---

## 七、本次实跑结果（2026-10-25）

课程：工程与社会（班级 <班级>）

- 未看 7 节，全部自动连播完成，实际挂机约 **17 分钟**（6 倍速）
- /plan：37 个叶子节点全部 `complete`，`TODO=0`
- /progress：我的进度 68% → **100%**；已观看视频 04:52:20 → **07:08:30**（+2:16:10）；视频观看 6.8 → **10 分（满分）**；「上次学到」= 第六章总结
- 仍为 0 的分项（不在本 Skill 范围）：测验、考试、讨论发帖、笔记

---

## 八、文件清单

| 文件 | 说明 |
|---|---|
| `在浙学视频刷课Skill总说明.md` | 本文档：坑总结 + 流程 + 完整驱动 + 实跑结果 |
| `SKILL.md` | 装进 Skill 目录的原始说明（含 frontmatter，用于触发） |
| `browser-recipes.md` | 参考资料原文（可直接粘贴的代码与事实表） |

Skill 安装位置：

```
C:\Users\MECHREVO\AppData\Local\Doubao\User Data\Default\.doubao\agent_mode\workspace\.user_skills\zjooc-video-runner\
```

配套 Skill：作业批量作答见 `zjooc-homework-runner`。

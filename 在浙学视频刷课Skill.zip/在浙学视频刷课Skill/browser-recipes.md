# 可复用实现（已实测通过）

在 `computer_use_tool(plane="bu")` 单元格里运行，`import seed_browser_use as bu`。每个单元格是新进程，helper 要一起带。

## 1. 列出未看章节（在 /plan 页执行）

叶子节点 = `.el-tree-node__content` 内含 `.is-leaf` 的节点；完成标记在内部 `<i>` 的类名里：
- `complete iconfont icon-shipin` → 已看视频
- `iconfont icon-shipin` → 未看视频
- `icon-file` → 文档/阅读类（无视频，跳过）

```python
d = bu.js("""(()=>{var cs=document.querySelectorAll('.el-tree-node__content'); var out=[];
for(var i=0;i<cs.length;i++){var c=cs[i]; if(!c.querySelector('.is-leaf')) continue;
 var ic=c.querySelector('i'); var cls=ic?(ic.className||''):'';
 var t=(c.innerText||'').replace(/\\s+/g,'');
 out.push(i+'|'+(cls.indexOf('complete')>=0?'DONE':'TODO')+'|'+(cls.indexOf('shipin')>=0?'video':'doc')+'|'+t.slice(0,20));}
return out.join('\\n');})()""")
print(d)
```

## 2. 注入自动连播驱动（一次性，全部在 /plan 页注入）

核心机制：页面里跑 `setInterval`，每 3 秒自检一次——
- 在 /plan 页：找第一个未看叶子 → 点击进入；
- 在详情页：等 `video.duration` 就绪 → 静音 + 6 倍速 + 播放；
- `ended` → 冷却 10 秒 → 点「返回章节列表」→ 回 /plan 重新找未看节点（不依赖固定下标，所以自动连播、标记延迟都能自愈）；
- 20 秒等不到 video 的节点（文档类）记进 `window.__skip`。

```python
JS = r"""
(function(){
try{
 var PLAN='https://www.zjooc.cn/ucenter/student/course/study/<courseId>/plan';
 var RATE=6;
 window.__log=[]; window.__start=Date.now(); window.__st='run';
 window.__todo=null; window.__ti=0; window.__cool=0; window.__cur=null;
 function L(m){ window.__log.push(Math.round((Date.now()-window.__start)/1000)+'s '+m);
   if(window.__log.length>400) window.__log.shift(); }
 function onPlan(){ return /\/plan$/.test(location.pathname); }
 function back(){
  var as=document.querySelectorAll('a,span,button,div');
  for(var i=0;i<as.length;i++){ if((as[i].innerText||'').trim()==='返回章节列表'){ as[i].click(); L('back to plan'); return 1; } }
  location.href=PLAN; return 0;
 }
 function computeTodo(){
  var cs=document.querySelectorAll('.el-tree-node__content'); var out=[];
  for(var i=0;i<cs.length;i++){ var c=cs[i]; if(!c.querySelector('.is-leaf')) continue;
   var ic=c.querySelector('i'); var cls=ic?(ic.className||''):'';
   if(cls.indexOf('complete')<0) out.push(i); }
  return out; }
 function doneIdx(i){ var cs=document.querySelectorAll('.el-tree-node__content'); var c=cs[i];
   if(!c) return true; var ic=c.querySelector('i'); return ic && (ic.className||'').indexOf('complete')>=0; }
 function tick(){
  try{
   if(window.__st==='done') return;
   if(Date.now()<window.__cool) return;
   if(window.__st==='run'){
    if(!onPlan()){ back(); window.__cool=Date.now()+5000; return; }
    if(window.__todo===null){ window.__todo=computeTodo(); L('TODO='+window.__todo.join(',')); }
    while(window.__ti<window.__todo.length && doneIdx(window.__todo[window.__ti])){ window.__ti++; }
    if(window.__ti>=window.__todo.length){ window.__st='done'; L('ALL DONE'); return; }
    var i=window.__todo[window.__ti];
    var cs=document.querySelectorAll('.el-tree-node__content'); var c=cs[i];
    window.__cur=(c.innerText||'').replace(/\s+/g,''); window.__t0=Date.now();
    c.click(); window.__st='playing'; L('open '+i+' '+window.__cur); return;
   }
   if(window.__st==='playing'){
    var v=document.querySelector('video');
    if(!v){ if(Date.now()-window.__t0>20000){ L('no video skip'); window.__ti++; window.__st='run'; window.__cool=Date.now()+3000; } return; }
    if(!(v.duration>0)){ if(Date.now()-window.__t0>20000){ L('no meta retry'); window.__st='run'; window.__cool=Date.now()+3000; } return; }
    if(v.ended){ L('END '+Math.round(v.currentTime)+'/'+Math.round(v.duration)+' '+window.__cur);
      window.__ti++; window.__st='run'; window.__cool=Date.now()+10000; return; }
    try{ v.muted=true; }catch(e){}
    try{ if(v.playbackRate<1.05) v.playbackRate=RATE; }catch(e){}
    try{ if(v.paused) v.play(); }catch(e){}
    if(window.__mark!==Math.round(v.currentTime/60)){ window.__mark=Math.round(v.currentTime/60);
      L('at '+Math.round(v.currentTime)+'/'+Math.round(v.duration)+' r='+v.playbackRate+' '+window.__cur); }
   }
  }catch(e){ L('err '+e.message); }
 }
 clearInterval(window.__t); window.__t=setInterval(tick,3000); tick();
 return 'driver installed';
}catch(e){ return 'ERR '+e.message; }
})()
"""
bu.navigate(PLAN)
bu.wait_for_load(timeout=25)
print(bu.js(JS))
```

## 3. 轻量轮询（注入后只做这个，别在单元格里循环等待）

```python
print(bu.js("(()=>{var v=document.querySelector('video'); var s=v?('c='+Math.round(v.currentTime)+'/'+Math.round(v.duration)+' r='+v.playbackRate+' p='+v.paused):'novideo'; return s+' | st='+window.__st+' ti='+window.__ti+' | '+(window.__log||[]).slice(-8).join(' || ');})()"))
```

单元格之间用 `Wait` 等 60–150 秒即可；一节 8–14 分钟的视频在 6 倍速下约 90–140 秒播完。

## 4. 全部完成后的双重复核

```python
# /plan 页：数 complete 叶子，应为 0 个 TODO
bu.js("""(()=>{var cs=document.querySelectorAll('.el-tree-node__content'); var todo=[],done=0;
for(var i=0;i<cs.length;i++){var c=cs[i]; if(!c.querySelector('.is-leaf')) continue;
 var ic=c.querySelector('i'); var cls=ic?(ic.className||''):'';
 if(cls.indexOf('complete')>=0) done++; else todo.push((c.innerText||'').replace(/\\s+/g,'').slice(0,16));}
return 'DONE='+done+' TODO='+todo.length+(todo.length?(' -> '+todo.join(',')):'');})()""")

# /progress 页：读我的进度 / 已观看视频 / 上次学到
bu.navigate(PLAN.rsplit('/',1)[0] + '/progress')
bu.wait_for_load(timeout=25)
print(bu.get_page_text())
```

## 5. 已核验的事实表（省去重新试探）

| 现象 | 结论 |
|---|---|
| 播放器控制条只有「高清」「广告」 | 无官方倍速入口 |
| `video.playbackRate=6` 后保持 6 | 倍速可写；8x 曾被播放器重置为 4，用 6x |
| 6 倍速播 17 分钟，已观看时长 +2:16:10 | 平台按**内容时长**记账，倍速真实折算 |
| 拖到片尾 / 直接 seek | 不计观看时长 |
| 未静音直接 `play()` | 可能被浏览器自动播放策略拒绝，paused 仍 true |
| 播放中 `duration` 突变 | 播放器自动连播下一节，驱动要回 /plan 重算 |
| 详情页树节点 | 无 `complete` 类，在上面算 TODO 会误判全完成 |
| 详情页截图 | 常为空白，以 DOM 数据为准 |
| 叶子 `<i class="complete ...">` | 完成标记的唯一权威来源 |

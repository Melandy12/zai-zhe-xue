---
name: zjooc-video-runner
description: 在浙江省高等学校在线开放课程共享平台（zjooc.cn，又称「在浙学」）上快速刷完课程章节视频（「章节内容」里的视频学习）。当用户要求「把视频看完/刷完」「视频没法倍速」「学习进度没到 100%」「按没看的章节把视频看完」，或提供 www.zjooc.cn/ucenter/student/course/study/.../plan 的章节链接时使用。覆盖按完成标记定位未看章节、HTML5 视频倍速静音自动连播、逐节核验 complete 标记、学习进度页复核。不用于作业/测验/考试（用 zjooc-homework-runner）与讨论发帖。
---

# 在浙学（zjooc）章节视频倍速自动连播

用 Browser Use（`computer_use_tool` + `plane="bu"` + `import seed_browser_use as bu`）操作真实页面。不要抓站点接口：视频是 blob/MSE 地址，且业务接口带签名 `time` 令牌，自造请求一律 404。

## 一句话结论

页面没有倍速按钮，但底层是标准 HTML5 `video`，`playbackRate` 可写。**静音（muted）+ `playbackRate=6` + `play()` 能正常播放，且平台按「内容时长」记账**：实测 6 倍速跑 17 分钟真实时间，「已观看视频」增加 2 小时 16 分（正好等于 7 个视频的内容时长），进度 68% → 100%。

## 前置条件

1. 打开课程页确认登录态：右上角有学生姓名即可；出现「请登录」立即 `interaction.request_action`（`type="browserControl"`），不要替用户输密码。
2. 页面路径：
   - 章节列表：`/ucenter/student/course/study/<courseId>/plan`
   - 视频页：`/ucenter/student/course/study/<courseId>/plan/detail/<id>`
   - 进度统计：`/ucenter/student/course/study/<courseId>/progress`

## 硬性约束（全是实测踩出来的，违反就白刷）

1. **必须在「章节列表」（/plan）页注入驱动脚本**。视频详情页左侧那套树是另一个结构（叶子上没有 `complete` 标记类），在详情页里找「未看章节」会得到 0 个，脚本会立刻误判 `ALL DONE`。
2. **完成判定以树节点的 `<i>` 类为准**：已看是 `<i class="complete iconfont icon-shipin">`，未看是 `<i class="iconfont icon-shipin">`；文档类是 `icon-file`。唯一可信来源是 `/plan` 页的 `.el-tree-node__content`，不要信「我在不在播放」。
3. **倍速要静音后起播**：`v.muted = true; v.playbackRate = 6; v.play();`。未静音的 `play()` 可能被浏览器自动播放策略拒绝（`paused` 仍为 true）。6 倍速稳定计入；8 倍速曾被播放器重置为 4，不追求 8x。
4. **拖进度条/跳到片尾不计数**：`currentTime` 可以拖、不回弹，但「已观看视频」纹丝不动，等于白拖。
5. **播放器会自动连播下一节**：播放中 `duration` 会突然变（843→886 这种），那是它自己切到下一节了，不是脚本错乱。所以驱动不要按固定下标硬走，每节结束后**回 /plan 重新计算第一个未完成节点**，自愈。
6. **完成标记有几秒延迟**：`ended` 后别急着再点同一节，留 10–12 秒冷却回列表，否则会重复打开。
7. **长任务不要在一个 `computer_use_tool` 单元格里轮询**：会 `COMMAND_TIMEOUT`。正确做法是把 `setInterval` 驱动注入页面，之后用轻量单元格/`Wait` 只读 `window.__log` 汇报。
8. 详情页 `screenshot()` 常是空白帧，不要靠截图判断播放状态，读 DOM（`video.currentTime/duration/paused/ended`）。

## 标准流程

1. `/plan` 页读所有叶子节点，列出未看清单（`complete` 类缺失的叶子；`icon-file` 文档类跳过）。
2. 注入连播驱动（完整代码见 `references/browser-recipes.md`）：
   - 在 /plan 计算第一个未看节点 → 点击进入；
   - 详情页等待 `video.duration > 0` → 静音、6 倍速、播放；
   - 检测 `ended` → 冷却 10 秒 → 点「返回章节列表」回 /plan → 重新计算未看节点；
   - 20 秒等不到 video 的节点判定为文档类，记入 skip 不再点。
3. 每 60–120 秒读一次 `window.__log` 汇报当前节与进度。
4. 全部 `ALL DONE` 后，在 /plan 重新数一遍：`DONE=37 TODO=0`（数字随课程）。
5. 再到 /progress 复核：「我的进度」「已观看视频」「视频观看」分数、「上次学到」是否为最后一节。三处都对上才算完成。

## 进度页口径（汇报时讲清）

- 「我的进度」= 已观看内容时长 / 全部内容时长；「已观看视频」累计按**内容时长**计，倍速有效。
- 「视频观看」是独立一项得分（本课满分 10），与作业、测验、考试、讨论发帖、笔记并列；刷视频只补这一项。
- 「上次学到」应等于最后一节标题。

## 参考资料

- `references/browser-recipes.md`：可直接粘贴的完整驱动脚本（自找未看节点、自动连播、自动倍速、自愈切节、日志），以及完成标记判定与核验脚本。

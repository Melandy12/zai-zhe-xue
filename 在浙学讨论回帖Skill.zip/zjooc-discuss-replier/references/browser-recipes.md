# 讨论区回帖可复用脚本（已实测通过）

以下代码全部在 `computer_use_tool(plane="bu")` 单元格内运行，`import seed_browser_use as bu`。每个 cell 都是新进程，helper 要随代码一起带上。

## 0. 常量

```python
COURSE = "8a22121fa079852501a08b122a31424c"
LIST = f"https://www.zjooc.cn/ucenter/student/course/study/{COURSE}/discuss/list?type=2"
DETAIL = "https://www.zjooc.cn/ucenter/student/course/study/" + COURSE + "/discuss/list/details/{pid}?pageNo=1"
```

## 1. 登录态校验与掉线恢复

```python
import time, json

LOGIN_URL = "https://www.zjooc.cn/"

def check_login():
    """返回 {logged, blocked, account}。logged=True 才可继续。"""
    return bu.js("""(()=>{
      var t=document.body.textContent||'';
      var hasLoginForm=!!document.querySelector('input[placeholder*="账号"],input[placeholder*="手机"],input[placeholder*="密码"],.login,form');
      var hasCaptcha=/验证码|扫码|登录/.test(t);
      var account=(document.querySelector('a[href*="profile"],.main-item-frist')||{}).textContent||'';
      var logged=/退出|我的课程|我的作业|我的讨论/.test(t) && !/请登录|登录后查看/.test(t);
      return JSON.stringify({logged:!!logged, blocked:!logged, account:account.trim()});
    })()""")

def ensure_login_ready():
    """未登录则交接用户；调用前已把登录页置于前台。"""
    st = json.loads(check_login())
    if st["logged"]:
        return "ok"
    # 登录/验证码卡点：交接，不代填、不绕过
    # interaction.request_action(type="browserControl", title="请登录在浙学",
    #   display_message="在浙学页面需要登录，请接管浏览器输入账号密码、完成图形验证码或扫码；登录成功、页面出现你的昵称后交回。")
    return "HANDOFF"

def recover_if_stale():
    """会话掉线 / ref 失效后重取附着。"""
    try:
        bu.resync()
        time.sleep(1)
        bu.snapshot()
        return "resynced"
    except Exception as e:
        return "resync_fail: " + str(e)
```

- 截图空白时不要判死：用 `check_login()` 读 DOM 文本判断登录态。
- 验证码/登录框被裁掉：`bu.navigate(LOGIN_URL)` 或新开标签页把表单带到前台，滚入视口后再交接。
- 交接前用 `bu.list_tabs()` 找到登录页标签并 `bu.switch_tab` 切到前台；交回后重新取 ref。

## 2. 提取列表主帖（区分主帖与回复）

```python
import json, time

def list_posts():
    bu.navigate(LIST)
    bu.wait_for_load(timeout=15)
    time.sleep(1.5)
    return bu.js("""(()=>{
      var out=[];
      [...document.querySelectorAll('.base-comment')].forEach((c,i)=>{
        var a=(c.querySelector('.main-item-frist')||{}).textContent||'';
        var author=a.trim();
        var links=[...c.querySelectorAll('a.main-item-01')];
        var title=links[0]?links[0].textContent.trim():'';
        var isReply=/回复/.test(author) || !links.length;
        out.push({i, author, isReply, title});
      });
      return JSON.stringify(out);
    })()""")
```

- 主帖：`isReply=false`，`author` 为发帖人；回复：作者名含“回复：”或无标题链接。
- 目标作者匹配前先 `replace(/\s+/g,'')`；列表有分页时逐页点击 `.el-pager li.number` 重复提取。

## 3. 进详情读全文与讨论问题

```python
def open_detail(pid):
    bu.navigate(DETAIL.format(pid=pid))
    bu.wait_for_load(timeout=15)
    time.sleep(1.5)

def detail_text():
    return bu.js("""(()=>{
      var t=document.body.textContent.replace(/\\s+/g,' ').trim();
      var i=t.indexOf('讨论区详情');
      return i>=0 ? t.slice(i) : t;
    })()""")
```

- 摘要在列表被“展开”截断，必须以详情全文为准。
- 定位“讨论：”之后的每个编号问题，回复逐条对应。

## 4. CKEditor 写入并提交

```python
def wait_ckeditor():
    for _ in range(6):
        ready = bu.js("(()=>{return (typeof CKEDITOR!=='undefined'&&Object.keys(CKEDITOR.instances).length>0)?1:0;})()")
        if int(ready) == 1:
            return True
        time.sleep(1)
    return False

def submit_reply(html):
    if not wait_ckeditor():
        return "NO_EDITOR"
    res = bu.js("""(function(){
      var id=Object.keys(CKEDITOR.instances)[0];
      var inst=CKEDITOR.instances[id];
      inst.setData(%s);
      return inst.getData().length;
    })()""" % json.dumps(html))
    if int(res or 0) <= 0:
        return "EMPTY_DATA"
    bu.js("""(()=>{var b=[...document.querySelectorAll('button')].find(x=>x.textContent.trim()==='提交');
      if(b){b.click(); return 1;} return 0;})()""")
    time.sleep(2.5)
    msg = bu.js("""(()=>{return [...document.querySelectorAll('.el-message')].map(e=>e.textContent.trim()).join('|');})()""")
    time.sleep(1.5)
    return msg or "NO_MSG"
```

- `html` 分段用 `<p>...</p>`；中文引号直接写，不要转义成实体。
- 成功信号：`msg` 含“提交成功”；本流程一般无 `.el-message-box` 确认弹窗。
- 成功后页面自动跳回 `LIST`（`?type=2&pageNo=1`）。

## 5. 翻评论分页核验本人回复

```python
def verify(pid, account, kw):
    bu.navigate(DETAIL.format(pid=pid))
    bu.wait_for_load(timeout=15); time.sleep(1.2)
    for p in range(1, 7):
        if p > 1:
            bu.js("""(()=>{var n=document.querySelectorAll('.el-pager li.number');
              if(n.length>=%d) n[%d-1].click();})()""" % (p, p))
            time.sleep(0.8)
        res = bu.js("""(()=>{
          var authors=[...document.querySelectorAll('.base-comment .main-item-frist')].map(e=>e.textContent.trim());
          var body=document.body.textContent;
          return JSON.stringify({authors, me:authors.includes(%s), kw:body.includes(%s)});
        })()""" % (json.dumps(account), json.dumps(kw)))
        if '"me":true' in res or '"kw":true' in res:
            return "FOUND page " + str(p)
    return "NOT_FOUND"
```

- `account` 用当前页面顶部显示名；`kw` 取回复正文里的独有短句（避免与他人回复撞词）。
- 核验必须限定 `.base-comment` 容器：顶部导航同名账号会污染整页 `includes` 判断。
- 本人回复常排在评论最后一页；`NOT_FOUND` 时先重读详情现状，确认是否真未提交，再决定是否重试，避免重复发帖。

## 6. 已核验 DOM 事实

| 项 | 事实 |
| --- | --- |
| 主帖/回复卡片 | 同为 `.base-comment`；回复作者名含“回复：” |
| 作者节点 | `.main-item-frist` |
| 标题/摘要链接 | `a.main-item-01` |
| 回复编辑器 | CKEditor iframe；底层 textarea 隐藏，id 形如 `2912.729284889388` |
| 实例读取 | `Object.keys(CKEDITOR.instances)[0]`；`inst.mode=wysiwyg`，`inst.editable().getName()=body` |
| 写入 API | `inst.setData(html)`；复核 `inst.getData().length` |
| 提交按钮 | 文本“提交”的 `button.el-button--primary.el-button--mini` |
| 成功提示 | `.el-message` 文本“提交成功” |
| 评论分页 | 详情页底部 `.el-pager li.number`，与主帖列表分页相互独立 |
| 旧入口 | `/build/discuss` 数据与课程内 `list?type=2` 不一致，找特定学生用新入口 |
